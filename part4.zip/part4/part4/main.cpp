#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>

using namespace std;


//Ma Petite Phrase//
string Cryptage(string phrase, int nbCaract);

int main()

{
    int nbr=0;
    string code;//Une variable pour stocker la phrase crypt�
    string non_code; //Une variable pour stocker la ligne lue


    ifstream fichier("code.txt");

    if(fichier)
    {
        //L'ouverture s'est bien pass�e, on peut donc lire

        while(getline(fichier, non_code)) //Tant qu'on n'est pas � la fin, on lit
        {
            cout<<"Voici la phrase qui est dans le dossier texte: "<< non_code << endl;
            cout<<" De combien voulez vous decaler: ";
            cin>> nbr;
            code = Cryptage(non_code, nbr);// decalage = la resultat de la fonction
        }



        cout<<" La phrase crypte et retourne est: "<<code<<endl;

    }
    else
    {
        cout << "ERREUR: De lecture du dossier." << endl;
    }

    string const Fichier("code.txt");
    ofstream file(Fichier.c_str());

    if(file)
    {
        file<< code << endl;
        //file<< "ceci est un test" << endl;
        file.close();
    }
    else
    {

        cout << "ERREUR: De lecture du dossier." << endl;
    }

    fichier.close();








    return 0;
}




string Cryptage(string phrase, int nbCaract)//Fonction pour le cryptage en inverse
{
    int i=0,j=0, decomtpe;
    decomtpe = phrase.length();// variable decompte= taille de phrase
    string phrases=phrase;//cr�ation d'une variable "phrases" de "phrase" pour pouvoir y stocker le message � crypter
    for (i=decomtpe-1; i>=0; i--) //boucle pour parcourir avec "i" et "j"
    {
        phrases[i]=phrase[j];//affectation de la lettre en partant du bas de la variable phrases
        j++;
    }

    i=0;

    string sortie=phrases;

    if (nbCaract>0 || nbCaract<25)
    {
        while (phrases[i] !='\0')
        {
            if (phrases[i] == ' ')
            {
                sortie[i]= ' ';
            }
            else
            {
                if (phrases[i] >='A' && phrases[i] <='Z' )
                {
                    sortie[i]=(((phrases[i]-65)+nbCaract)%26)+65;
                }
                if (phrases[i] >='a' && phrases[i] <='z' )
                {
                    sortie[i]=(((phrases[i]-97)+nbCaract)%26)+97;
                }
            }

            i++;
        }
    }
    return sortie;

}
