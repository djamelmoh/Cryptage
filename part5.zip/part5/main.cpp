
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>

using namespace std;



string Cryptage(string phrase, int nbCaract);
string DeCryptage(string phrase, int nbCaract);

int main()

{
    int nbr=0,choix=0;
    string Phrase;
    string phrase_dossier;

    cout<<" Voulez-vous chiffrer (taper 1) ou dechiffrer  le fichier.txt (taper 2) "<<endl;

    cin>>choix;

    if(choix==1)
    {
        
        
        ifstream fichier("chiffrement.txt");

        if(fichier)
        {
            //Ouverture du dossier

            string phrase_dossier; //Variable pour stocker les lignes lues
            while(getline(fichier, phrase_dossier)) //Tant qu'on n'est pas � la fin du dossier, on continue la lecture
            {
                cout<<"                                   "<<endl;
                cout<<" La Phrase dans le fichier est : "<<phrase_dossier << endl;
                cout<<"                                   "<<endl;
                
                cout<<" De combien voulez-vous decaler ? >>> "<<endl;
    
                cin>> nbr;
                Phrase = Cryptage(phrase_dossier, nbr);// decalage = la resultat de la fonction
            }



            cout<<" La phrase crypter donne >>> "<<Phrase<<endl;

        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier en lecture." << endl;
        }

        string const Fichier("chiffrement.txt");
        ofstream monFlux(Fichier.c_str());

        if(monFlux)
        {
            monFlux<< Phrase << endl;
            
            monFlux.close();
        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier." << endl;
        }

        fichier.close();



    }

    else if(choix==2)
    {


        ifstream fichier("chiffrement.txt");

        if(fichier)
        {
               //Ouverture du dossier

            string phrase_dossier; //Une variable pour stocker les lignes lues
            while(getline(fichier, phrase_dossier)) //Tant qu'on n'est pas � la fin du dossier, on continue la lecture
            {
                cout<<"                                   "<<endl;
                cout<<" La Phrase dans le fichier est : "<<phrase_dossier << endl;
                cout<<"                                   "<<endl;
             
                cout<<" De combien voulez-vous decaler ? >>> "<<endl;
                
                cin>> nbr;
                Phrase = DeCryptage(phrase_dossier, nbr);// decalage = la resultat de la fonction
            }




            cout<<" La phrase decrypter donne >>> "<<Phrase<<endl;

        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier en lecture." << endl;
        }

        string const Fichier("chiffrement.txt");
        ofstream monFlux(Fichier.c_str());

        if(monFlux)
        {
            monFlux<< Phrase << endl;
            //monFlux<< "ceci est un test" << endl;
            monFlux.close();
        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier." << endl;
        }

        fichier.close();


    }




    return 0;
}




string Cryptage(string phrase, int nbCaract)//Fonction pour le cryptage en inverse
{
    int i=0,j=0, decomtpe;
    decomtpe = phrase.length();// variable decompte= taille de phrase
    string copie_phrase=phrase;//cr�ation d'une variable "copie_phrase" de "phrase" pour pouvoir y stocker le message � crypter
    for (i=decomtpe-1; i>=0; i--) //boucle pour parcourir avec "i" et "j"
    {
        copie_phrase[i]=phrase[j];//affectation de la lettre en partant du bas de la variable copie_phrase
        j++;
    }

    i=0;

    string sortie=copie_phrase;

    if (nbCaract>0 || nbCaract<25)
    {
        while (copie_phrase[i] !='\0')
        {
            if (copie_phrase[i] == ' ')
            {
                sortie[i]= ' ';
            }
            else
            {
                if (copie_phrase[i] >='A' && copie_phrase[i] <='Z' );
                {
                    sortie[i]=(((copie_phrase[i]-65)+nbCaract)%26)+65;
                }
                if (copie_phrase[i] >='a' && copie_phrase[i] <='z' );
                {
                    sortie[i]=(((copie_phrase[i]-97)+nbCaract)%26)+97;
                }
            }

            i++;
        }
    }
    return sortie;

}


string DeCryptage(string phrase, int nbCaract)
{
    int i=0,j=0, decomtpe;
    decomtpe = phrase.length();
    nbCaract=26-nbCaract;

    string sortie=phrase;

    if (nbCaract>0 || nbCaract<25)
    {
        while (phrase[i] !='\0')
        {
            if (phrase[i] == ' ')
            {
                sortie[i]= ' ';
            }
            else
            {
                if (phrase[i] >='A' && phrase[i] <='Z' );
                {
                    sortie[i]=(((phrase[i]-65)+nbCaract)%26)+65;
                }
                if (phrase[i] >='a' && phrase[i] <='z' );
                {
                    sortie[i]=(((phrase[i]-97)+nbCaract)%26)+97;
                }
            }

            i++;
        }
    }

    string copie_phrase=sortie;

    for (i=decomtpe-1; i>=0; i--)
    {
        copie_phrase[i]=sortie[j];
        j++;
    }

    i=0;
    return copie_phrase;

}
