#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>

using namespace std;


//Ma Petite Phrase//
string Cryptage(string phrase, int nbCaract);

string decalePhrase(string phrase1, int nbCaract1);//d�claration fonction

int main()

{
    int nbr=0;
    string code;//Une variable pour stocker la phrase crypt�
    string non_code; //Une variable pour stocker la ligne lue
	int x=0;
	
	cout<<"Voulez-vous crypter une phrase (taper 1) ou crypter un dossier (taper 2)\n";
	cin>>x;
	
	if(x==1)
	{
		
    struct fonct
    {
        string phrase;
        string message_crypter;
        int decalage;

    };

    fonct structure;

    cout<<"Quel Phrase voulez vous crypter"<<endl;
    getline(cin,structure.phrase);//entrer phrase


    cout<<"De combien voulez vous decaler"<<endl;
    cin>> structure.decalage;//entrer chiffre pour d�caler

    structure.message_crypter = decalePhrase(structure.phrase, structure.decalage);// decalage = la resultat de la fonction

    cout<<" La phrase que vous avez rentre est: "<<structure.phrase<<endl;//affiche phrase

    cout<<"Vous voulez un decalage de: "<<structure.decalage<<endl;//nbr de decallage phrase

    cout<<" Voici votre phrase crypte et inverse : "<<structure.message_crypter<<endl;//phrase d�cal� et invers�


	}

else if(x==2)
  {
  	  ifstream fichier("code.txt");

    if(fichier)
    {
        //L'ouverture s'est bien pass�e, on peut donc lire

        while(getline(fichier, non_code)) //Tant qu'on n'est pas � la fin, on lit
        {
            cout<<"Voici la phrase qui est dans le dossier texte: "<< non_code << endl;
            cout<<" De combien voulez vous decaler: ";
            cin>> nbr;
            code = Cryptage(non_code, nbr);// decalage = la resultat de la fonction
        }



        cout<<" La phrase crypte et retourne est: "<<code<<endl;

    }
    else
    {
        cout << "ERREUR: De lecture du dossier." << endl;
    }

    string const Fichier("code.txt");
    ofstream file(Fichier.c_str());

    if(file)
    {
        file<< code << endl;
        //file<< "ceci est un test" << endl;
        file.close();
    }
    else
    {

        cout << "ERREUR: De lecture du dossier." << endl;
    }

    fichier.close();



  }





    return 0;
}




string Cryptage(string phrase, int nbCaract)//Fonction pour le cryptage en inverse
{
    int i=0,j=0, decomtpe;
    decomtpe = phrase.length();// variable decompte= taille de phrase
    string phrases=phrase;//cr�ation d'une variable "phrases" de "phrase" pour pouvoir y stocker le message � crypter
    for (i=decomtpe-1; i>=0; i--) //boucle pour parcourir avec "i" et "j"
    {
        phrases[i]=phrase[j];//affectation de la lettre en partant du bas de la variable phrases
        j++;
    }

    i=0;

    string sortie=phrases;

    if (nbCaract>0 || nbCaract<25)
    {
        while (phrases[i] !='\0')
        {
            if (phrases[i] == ' ')
            {
                sortie[i]= ' ';
            }
            else
            {
                if (phrases[i] >='A' && phrases[i] <='Z' )
                {
                    sortie[i]=(((phrases[i]-65)+nbCaract)%26)+65;
                }
                if (phrases[i] >='a' && phrases[i] <='z' )
                {
                    sortie[i]=(((phrases[i]-97)+nbCaract)%26)+97;
                }
            }

            i++;
        }
    }
    return sortie;

}

string decalePhrase(string phrase1, int nbCaract1)//Fonction pour le cryptage en inverse
{
    int i=0,j=0, taille_phrase;
    taille_phrase = phrase1.length();// variable taille_phrase= taille de phrase
    string message_crypter=phrase1;//cr�ation d'une variable "message_crypter" de "phrase" 
    for (i=taille_phrase-1; i>=0; i--) //boucle pour parcourir avec "i" et "j" //taille_phrase-1 car la dernierre lettre du mot est pris en compte 
    {
        message_crypter[i]=phrase1[j];//affectation de la lettre en partant du bas de la variable message_crypter
        j++;
    }

    i=0;

    string phrases=phrase1;

    if (nbCaract1>0 || nbCaract1<25)//si longueur inf � 0 et sup � 25 alors
    {
        while (message_crypter[i] !='\0')//tant que se n'est pas egale � l'antislache 0
        {
            if (message_crypter[i] == ' ')//si des espaces
            {
                phrases[i]= ' ';
            }
            else
            {
                if (message_crypter[i] >='A' && message_crypter[i] <='Z' );//si la lettre egale � des lettre majuscule
                {
                    phrases[i]=(((message_crypter[i]-65)+nbCaract1)%26)+65;//alors la lettre va recevoir le decallage demand�
                }
                if (message_crypter[i] >='a' && message_crypter[i] <='z' );//si la lettre egale � des lettre minuscule
                {
                    phrases[i]=(((message_crypter[i]-97)+nbCaract1)%26)+97;//alors la lettre va recevoir le decallage demand�
                }
            }

            i++;
        }
    }
    return phrases;//renvoie phrase crypt�

}
