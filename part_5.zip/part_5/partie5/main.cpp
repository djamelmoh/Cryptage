#include <iostream>
#include <cstring>
#include <cstdlib>
#include <fstream>

using namespace std;



string Cryptage(string phrase, int nbCaract);
string DeCryptage(string phrase, int nbCaract);

int main()

{
    int nbr=0,choix=0;
    string Phrase;
    string phrases;
    int x;


    cout<<"Voulez-vous crypter un dossier (taper 1) ou crypter une phrase (taper 2)"<<endl;

    cin>>x;

    if(x==1)
    {


        cout<<" Voulez-vous chiffrer (taper 1) ou dechiffrer le fichier.txt (taper 2) "<<endl;

        cin>>choix;

        cin.ignore();

        if(choix==1)
{

    ifstream fichier("chiffrement.txt");

        if(fichier)
        {
            //L'ouverture s'est bien pass�e, on peut donc lire

            string phrases; //Une variable pour stocker les lignes lues
            while(getline(fichier, phrases)) //Tant qu'on n'est pas � la fin, on lit
            {
                cout<<"                                   "<<endl;
                cout<<" La Phrase dans le fichier est : "<<phrases << endl;
                cout<<"                                   "<<endl;
               ;
                cout<<" De combien voulez-vous decaler ? "<<endl;

                cin>> nbr;
                Phrase = Cryptage(phrases, nbr);// decalage = la resultat de la fonction
            }



            cout<<" La phrase crypter donne  "<<Phrase<<endl;

        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier en lecture." << endl;
        }

        string const Fichier("chiffrement.txt");
        ofstream monFlux(Fichier.c_str());

        if(monFlux)
        {
            monFlux<< Phrase << endl;
            //monFlux<< "ceci est un test" << endl;
            monFlux.close();
        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier." << endl;
        }

        fichier.close();



    }

    else if(choix==2)
{


    ifstream fichier("chiffrement.txt");

        if(fichier)
        {
            //L'ouverture s'est bien pass�e, on peut donc lire

            string phrases; //Une variable pour stocker les lignes lues
            while(getline(fichier, phrases)) //Tant qu'on n'est pas � la fin, on lit
            {
                cout<<"                                   "<<endl;
                cout<<" La Phrase dans le fichier est : "<<phrases << endl;
                cout<<"                                   "<<endl;

                cout<<" De combien voulez-vous decaler ?  "<<endl;

                cin>> nbr;
                Phrase = DeCryptage(phrases, nbr);// decalage = la resultat de la fonction
            }




            cout<<" La phrase decrypter donne  "<<Phrase<<endl;

        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier en lecture." << endl;
        }

        string const Fichier("chiffrement.txt");
        ofstream monFlux(Fichier.c_str());

        if(monFlux)
        {
            monFlux<< Phrase << endl;
            //monFlux<< "ceci est un test" << endl;
            monFlux.close();
        }
        else
        {
            cout << " ERREUR: Impossible d'ouvrir le fichier." << endl;
        }

        fichier.close();


    }
    }

    else if(x==2)
    {



        cout<<" Voulez-vous chiffrer (taper 1) ou dechiffrer le fichier.txt (taper 2)  "<<endl;

        cin>>choix;
        cin.ignore();

        if(choix==1)
{


    //L'ouverture s'est bien pass�e, on peut donc lire

    string phrases; //Une variable pour stocker les lignes lues



    cout<<" Quelle Phrase voulez-vous crypter ? "<<endl;
    getline(cin,phrases);

    cout<<" De combien voulez-vous decaler ?  "<<endl;

    cin>> nbr;
    Phrase = Cryptage(phrases, nbr);// decalage = la resultat de la fonction





        cout<<" La phrase crypter donne  "<<Phrase<<endl;




    }

    else if(choix==2)
{

    //L'ouverture s'est bien pass�e, on peut donc lire

    string phrases; //Une variable pour stocker les lignes lues

    cout<<" Quelle Phrase voulez-vous decrypter ? "<<endl;
    getline(cin,phrases);

    cout<<" De combien voulez-vous decaler ?  "<<endl;

    cin>> nbr;
    Phrase= DeCryptage(phrases, nbr);// decalage = la resultat de la fonction





        cout<<" La phrase decrypter donne  "<<Phrase<<endl;


    }

    }






    return 0;
}




string Cryptage(string phrase, int nbCaract)//Fonction pour le cryptage en inverse
{
    int i=0,j=0, decomtpe;
    decomtpe = phrase.length();// variable decompte= taille de phrase
    string message_phrase=phrase;//cr�ation d'une variable "message_phrase" de "phrase" pour pouvoir y stocker le message � crypter
    for (i=decomtpe-1; i>=0; i--) //boucle pour parcourir avec "i" et "j"
    {
        message_phrase[i]=phrase[j];//affectation de la lettre en partant du bas de la variable message_phrase
        j++;
    }

    i=0;

    string sortie=message_phrase;

    if (nbCaract>0 || nbCaract<25)
    {
        while (message_phrase[i] !='\0')
        {
            if (message_phrase[i] == ' ')
            {
                sortie[i]= ' ';
            }
            else
            {
                if (message_phrase[i] >='A' && message_phrase[i] <='Z' )
                {
                    sortie[i]=(((message_phrase[i]-65)+nbCaract)%26)+65;
                }
                if (message_phrase[i] >='a' && message_phrase[i] <='z' )
                {
                    sortie[i]=(((message_phrase[i]-97)+nbCaract)%26)+97;
                }
            }

            i++;
        }
    }
    return sortie;

}


string DeCryptage(string phrase, int nbCaract)
{
    int i=0,j=0, decomtpe;
    decomtpe = phrase.length();
    nbCaract=26-nbCaract;

    string sortie=phrase;

    if (nbCaract>0 || nbCaract<25)
    {
        while (phrase[i] !='\0')
        {
            if (phrase[i] == ' ')
            {
                sortie[i]= ' ';
            }
            else
            {
                if (phrase[i] >='A' && phrase[i] <='Z' )
                {
                    sortie[i]=(((phrase[i]-65)+nbCaract)%26)+65;
                }
                if (phrase[i] >='a' && phrase[i] <='z' )
                {
                    sortie[i]=(((phrase[i]-97)+nbCaract)%26)+97;
                }
            }

            i++;
        }
    }

    string clone=sortie;

    for (i=decomtpe-1; i>=0; i--)
    {
        clone[i]=sortie[j];
        j++;
    }

    i=0;
    return clone;

}
